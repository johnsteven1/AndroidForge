# Build Instructions
- Android Studio with Android SDK Platform 35
- JDK 17
- Network access for first-time Gradle dependency resolution

Open the folder containing `settings.gradle.kts`, allow Gradle sync, then use **Build > Make Project** and **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

If Gradle is installed locally, run `gradle assembleDebug`. To create an official Gradle wrapper locally, run `gradle wrapper --gradle-version 8.9`, then `./gradlew assembleDebug`.

Overlay and Accessibility permissions are optional and must be granted by the user. APK access uses Android's system document picker.
