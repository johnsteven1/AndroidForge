# Third-party licenses
This project declares dependencies from AndroidX, Jetpack Compose, Navigation Compose, AndroidX Room, and AndroidX WebKit. Review the licenses for the exact dependency versions resolved by Gradle before distribution. No third-party APKs, credentials, signing keys, or SecureVault files are included.
