# App Inspector Pro

This project replaces the SecureVault project with a native Kotlin/Jetpack Compose Android Studio project.

## Included
- Dark Compose dashboard and navigation
- Edit Mode with tap-to-select text in the app's integrated WebView
- Replacement text field, apply, and undo workflow for the current page
- Launchable installed-app library
- Official Google Play Store intents with web fallback
- Read-only APK metadata inspection via Android's document picker
- Room-backed local editing history
- Movable floating shortcut overlay
- Opt-in Accessibility Service declaration
- Privacy and compatibility notes

## Build
1. Install Android Studio, Android SDK Platform 35, and JDK 17.
2. Open the `AppInspectorPro` folder.
3. Allow Gradle sync to download dependencies.
4. Select **Build > Make Project**.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Expected APK path: `app/build/outputs/apk/debug/app-debug.apk`.

The environment used to package this archive had no Android SDK or Gradle installation and no network access, so compilation and device tests were not possible. The Gradle wrapper scripts included here use a locally installed Gradle; if needed, run `gradle wrapper --gradle-version 8.9` from the project root to generate the official wrapper JAR.

## Use Edit Mode
Open **Edit Mode**, enter a web address, press **GO**, enable **Tap-to-select**, tap a text-bearing element, edit the replacement field, then press **APPLY**. Changes affect the current WebView DOM only. Reloading may discard them.

## Google Play
The Play Store screen opens official `market://` intents and falls back to the official Google Play website if the app is unavailable. It does not copy Google's UI or bypass installation consent.

## Cross-app inspection
The app library lists launchable apps visible under Android package-visibility rules. The **INSPECT** action opens Android Accessibility settings. The service must be enabled manually and does not rewrite another app's private view state. Android does not permit universal arbitrary text modification across unrelated apps.

## APK Inspector
Choose an APK with the system document picker. It is parsed locally and is not executed or installed. This starter shows app/package/version, size, SDK values where available, and declared permissions. Certificate fingerprints, resource browsing, APK rebuilding, and signing are not implemented.

## Floating inspector
Settings > Floating inspector requests overlay permission when enabled. Tap the movable pencil to return to App Inspector Pro; long-press to stop it.

## Privacy
No inspected content is uploaded by this project. Imported APKs are read locally. History is stored locally and can be cleared. Review current Google Play policies before publishing, especially policies governing Accessibility Services and overlays.
