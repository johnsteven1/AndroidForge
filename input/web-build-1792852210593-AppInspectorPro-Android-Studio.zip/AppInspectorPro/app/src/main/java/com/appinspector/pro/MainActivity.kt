package com.appinspector.pro

import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.appinspector.pro.accessibility.InspectorAccessibilityService
import com.appinspector.pro.data.*
import com.appinspector.pro.inspector.FloatingInspectorService
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.DateFormat
import java.util.Date

private val BG=Color(0xFF080B12); private val CARD=Color(0xFF121826); private val ACC=Color(0xFF8B7CFF); private val MUTED=Color(0xFFAAB4C8)
private enum class Page(val title:String) { HOME("Home"), EDIT("Edit Mode"), APPS("My Apps"), STORE("Play Store"), APK("APK Inspector"), FILES("File Manager"), HISTORY("History"), SETTINGS("Settings") }

class MainActivity: ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { InspectorApp() } }
}

@Composable private fun InspectorApp() {
 val ctx= LocalContext.current; val db= remember { AppDatabase.get(ctx) }; val scope= rememberCoroutineScope()
 var page by remember { mutableStateOf(Page.HOME) }; var editMode by remember { mutableStateOf(false) }
 var address by remember { mutableStateOf("https://example.com") }; var tag by remember { mutableStateOf("") }
 var original by remember { mutableStateOf("") }; var replacement by remember { mutableStateOf("") }
 var status by remember { mutableStateOf("Ready") }; var report by remember { mutableStateOf("Choose an APK to inspect its metadata.") }
 var refresh by remember { mutableIntStateOf(0) }; var web by remember { mutableStateOf<WebView?>(null) }
 val apkPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
  if(uri!=null) { report=inspectApk(ctx,uri); status=if(report.startsWith("Could not")) "APK inspection failed" else "APK inspected" }
 }
 MaterialTheme(colorScheme=darkColorScheme(primary=ACC, background=BG, surface=CARD, onSurface=Color.White, onBackground=Color.White)) {
  Scaffold(containerColor=BG, topBar={
   Row(Modifier.fillMaxWidth().background(CARD).padding(18.dp), verticalAlignment=Alignment.CenterVertically) {
    Column(Modifier.weight(1f)) { Text("APP INSPECTOR", color=MUTED, fontSize=10.sp, letterSpacing=2.sp); Text("Pro", fontSize=26.sp, fontWeight=FontWeight.ExtraBold) }
    Text(if(editMode) "EDIT MODE ON" else "READY", color=if(editMode) ACC else MUTED, fontSize=11.sp, fontWeight=FontWeight.Bold)
   }
  }, bottomBar={
   NavigationBar(containerColor=CARD) {
    listOf(Page.HOME,Page.EDIT,Page.APPS,Page.APK,Page.SETTINGS).forEach { p ->
     NavigationBarItem(selected=page==p,onClick={page=p},icon={ Icon(when(p){Page.HOME->Icons.Default.Home;Page.EDIT->Icons.Default.Edit;Page.APPS->Icons.Default.Apps;Page.APK->Icons.Default.FolderOpen;else->Icons.Default.Settings},null) },label={Text(p.title,fontSize=10.sp)})
    }
   }
  }) { pad ->
   Column(Modifier.fillMaxSize().padding(pad)) {
    when(page) {
     Page.HOME -> LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
      item { CardBlock { Text("Inspect. Select. Edit.",fontSize=24.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text("Edit text in your own browser workspace and inspect accessible elements in supported apps.",color=MUTED); Spacer(Modifier.height(14.dp)); Button(onClick={editMode=!editMode;status=if(editMode)"Edit Mode active" else "Edit Mode stopped"},modifier=Modifier.fillMaxWidth()){Text(if(editMode)"Turn Edit Mode Off" else "Activate Edit Mode")}; Text("Status: $status",color=MUTED,fontSize=12.sp,modifier=Modifier.padding(top=8.dp)) } }
      items(listOf("Edit Mode" to Page.EDIT,"My Apps" to Page.APPS,"Google Play Store" to Page.STORE,"APK Inspector" to Page.APK,"File Manager" to Page.FILES,"Editing History" to Page.HISTORY,"Settings" to Page.SETTINGS)) { (name,dest) -> CardBlock(Modifier.clickable{page=dest}) { Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(name,fontWeight=FontWeight.SemiBold);Text("Open $name tools",color=MUTED,fontSize=12.sp)};Icon(Icons.Default.ChevronRight,null,tint=ACC)} } }
      item { Text("Cross-app edits depend on Android permissions and the target app's exposed controls.",color=MUTED,fontSize=11.sp) }
     }
     Page.EDIT -> Column(Modifier.fillMaxSize().padding(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
      Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)) {
       OutlinedTextField(address,{address=it},modifier=Modifier.weight(1f),singleLine=true,label={Text("Web address")})
       Button(onClick={val u=if(address.startsWith("http"))address else "https://$address";address=u;web?.loadUrl(u)}){Text("GO")}
      }
      Row(verticalAlignment=Alignment.CenterVertically){Text("Tap-to-select text",Modifier.weight(1f),fontWeight=FontWeight.Bold);FilterChip(selected=editMode,onClick={editMode=!editMode;status=if(editMode)"Edit Mode active" else "Edit Mode stopped"},label={Text(if(editMode)"ON" else "OFF")})}
      AndroidView(modifier=Modifier.weight(1f).fillMaxWidth(),factory={c ->
       WebView(c).apply {
        settings.javaScriptEnabled=true;settings.domStorageEnabled=true
        webViewClient=object:WebViewClient(){override fun onPageFinished(v:WebView,url:String){super.onPageFinished(v,url);if(editMode)installSelector(v)}}
        webChromeClient=object:WebChromeClient(){
         override fun onJsPrompt(view:WebView?,origin:String?,message:String?,defaultValue:String?,result:JsPromptResult?):Boolean {
          if(message?.startsWith("APP_INSPECTOR:")==true){try{val j=JSONObject(message.removePrefix("APP_INSPECTOR:"));tag=j.optString("tag");original=j.optString("text");replacement=original;status="Element selected"}catch(_:Exception){};result?.confirm("");return true}
          return super.onJsPrompt(view,origin,message,defaultValue,result)
         }
        }
        loadUrl(address);web=this
       }
      },update={if(editMode)installSelector(it)})
      CardBlock {
       Text("SELECTED ELEMENT",color=MUTED,fontSize=10.sp,fontWeight=FontWeight.Bold)
       Text(if(tag.isBlank())"Tap a text element while Edit Mode is ON." else tag,color=ACC,fontWeight=FontWeight.Bold)
       Text("Original: ${if(original.isBlank())"—" else original}",color=MUTED,fontSize=11.sp,maxLines=2,overflow=TextOverflow.Ellipsis)
       OutlinedTextField(replacement,{replacement=it},modifier=Modifier.fillMaxWidth(),label={Text("Replacement text")},maxLines=3)
       Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
        Button(onClick={
         val w=web
         if(tag.isBlank()||w==null) status="Select a text element first" else w.evaluateJavascript("(function(){var e=document.querySelector('[data-app-inspector-selected=\"1\"]');if(!e)return 'NOT_FOUND';e.innerText=${JSONObject.quote(replacement)};return 'OK';})()") { result ->
          if(result?.contains("OK")==true){status="Applied to current page";scope.launch{db.historyDao().insert(EditHistory(target=address,elementType=tag,originalText=original.take(500),replacementText=replacement.take(500),result="Applied to current WebView page",timestamp=System.currentTimeMillis()));refresh++}} else status="Could not apply; select element again"
         }
        },modifier=Modifier.weight(1f)){Text("APPLY")}
        OutlinedButton(onClick={web?.evaluateJavascript("(function(){var e=document.querySelector('[data-app-inspector-selected=\"1\"]');if(!e)return 'NOT_FOUND';e.innerText=${JSONObject.quote(original)};return 'OK';})()"){status="Undo requested"};replacement=original},modifier=Modifier.weight(1f)){Text("UNDO")}
       }
       Text(status,color=MUTED,fontSize=11.sp)
       Text("Changes are temporary and may disappear when the page reloads.",color=MUTED,fontSize=10.sp)
      }
     }
     Page.APPS -> AppsPage(ctx,onOpen={pkg->val i=ctx.packageManager.getLaunchIntentForPackage(pkg);if(i!=null)ctx.startActivity(i) else status="No launch activity"},onInspect={page=Page.SETTINGS;status="Enable Accessibility manually to inspect supported UI elements."})
     Page.STORE -> StorePage()
     Page.APK -> Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("APK Inspector",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Read-only metadata inspection. Files are not executed or installed.",color=MUTED);Button(onClick={apkPicker.launch(arrayOf("application/vnd.android.package-archive","application/octet-stream"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.FolderOpen,null);Spacer(Modifier.width(8.dp));Text("Choose APK")};CardBlock{Text(report,fontSize=13.sp,lineHeight=20.sp)}}
     Page.FILES -> Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("File Manager",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Choose files using Android's document picker. Only selected files are accessible.",color=MUTED);Button(onClick={apkPicker.launch(arrayOf("*/*"))},modifier=Modifier.fillMaxWidth()){Text("Select a file")}}
     Page.HISTORY -> HistoryPage(db,refresh)
     Page.SETTINGS -> Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
      Text("Settings & Permissions",fontSize=24.sp,fontWeight=FontWeight.Bold)
      SettingCard("Floating inspector","Requires Android overlay permission","ENABLE"){if(Settings.canDrawOverlays(ctx))ContextCompat.startForegroundService(ctx,Intent(ctx,FloatingInspectorService::class.java)) else ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:${ctx.packageName}")))}
      SettingCard("Stop floating inspector","Stop the movable control","STOP"){ctx.stopService(Intent(ctx,FloatingInspectorService::class.java))}
      SettingCard("Accessibility inspection","Enable the service manually in Android Settings","OPEN SETTINGS"){ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}
      SettingCard("Edit Mode","Toggle browser element selection",if(editMode)"ON" else "OFF"){editMode=!editMode}
      CardBlock{Text("Privacy",fontWeight=FontWeight.Bold);Text("Browser edits stay in the current WebView session. APK inspection is local and read-only. Accessibility cannot universally rewrite other apps.",color=MUTED,fontSize=12.sp)}
     }
    }
   }
  }
 }
}

@Composable private fun CardBlock(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit){Surface(modifier.fillMaxWidth(),color=CARD,shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp),content=content)}}
@Composable private fun SettingCard(title:String,subtitle:String,action:String,onClick:()->Unit){CardBlock(Modifier.clickable{onClick()}){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.SemiBold);Text(subtitle,color=MUTED,fontSize=11.sp)};Text(action,color=ACC,fontSize=10.sp,fontWeight=FontWeight.Bold)}}}

private fun installSelector(web:WebView) {
 val js = """(function(){if(window.__appInspectorInstalled)return;window.__appInspectorInstalled=true;document.addEventListener('click',function(ev){var el=ev.target;if(!el)return;var text=(el.innerText||el.textContent||'').trim();if(!text)return;ev.preventDefault();ev.stopPropagation();document.querySelectorAll('[data-app-inspector-selected="1"]').forEach(function(n){n.removeAttribute('data-app-inspector-selected');n.style.outline='';});el.setAttribute('data-app-inspector-selected','1');el.style.outline='2px solid #8B7CFF';prompt('APP_INSPECTOR:'+JSON.stringify({tag:el.tagName,text:text.slice(0,2000)}),'');},true);})()"""
 web.evaluateJavascript(js,null)
}

private fun loadApps(ctx:Context):List<Pair<String,String>> {
 val intent=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
 return ctx.packageManager.queryIntentActivities(intent,PackageManager.MATCH_ALL)
  .map{it.loadLabel(ctx.packageManager).toString() to it.activityInfo.packageName}.distinctBy{it.second}.sortedBy{it.first.lowercase()}
}
@Composable private fun AppsPage(ctx:Context,onOpen:(String)->Unit,onInspect:(String)->Unit) {
 var q by remember{mutableStateOf("")};var apps by remember{mutableStateOf(loadApps(ctx))}
 Column(Modifier.fillMaxSize().padding(16.dp)){Text("My Apps",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Launchable apps visible to Android's package-visibility rules.",color=MUTED,fontSize=12.sp);OutlinedTextField(q,{q=it},modifier=Modifier.fillMaxWidth(),label={Text("Search apps")},singleLine=true);OutlinedButton(onClick={apps=loadApps(ctx)},modifier=Modifier.fillMaxWidth()){Text("Refresh library")}
 LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(apps.filter{it.first.contains(q,true)||it.second.contains(q,true)}){app->CardBlock{Text(app.first,fontWeight=FontWeight.SemiBold);Text(app.second,color=MUTED,fontSize=10.sp);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={onOpen(app.second)},modifier=Modifier.weight(1f)){Text("OPEN")};OutlinedButton(onClick={onInspect(app.second)},modifier=Modifier.weight(1f)){Text("INSPECT")}}}}}
 }
}
@Composable private fun StorePage() {
 val ctx=LocalContext.current;var q by remember{mutableStateOf("")};var message by remember{mutableStateOf("Search opens Google's official Play Store or its website fallback.")}
 Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Google Play Store",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Discover apps through Google's official store. Installation remains under Play Store and Android control.",color=MUTED);OutlinedTextField(q,{q=it},modifier=Modifier.fillMaxWidth(),label={Text("App or game")},singleLine=true)
 Button(onClick={val query=Uri.encode(q);try{ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("market://search?q=$query")));message="Opened Google Play."}catch(_:ActivityNotFoundException){ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/search?q=$query")));message="Opened Google Play website."}},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Shop,null);Spacer(Modifier.width(8.dp));Text("Search Google Play")}
 OutlinedButton(onClick={try{ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id=com.android.chrome")))}catch(_:Exception){ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store")))},modifier=Modifier.fillMaxWidth()){Text("Open Play Store")};CardBlock{Text(message,color=MUTED)}
 }
}
private fun inspectApk(ctx:Context,uri:Uri):String=try{
 val f=File(ctx.cacheDir,"inspector-${System.currentTimeMillis()}.apk")
 ctx.contentResolver.openInputStream(uri).use{input->if(input==null)return "Could not open selected file.";FileOutputStream(f).use{input.copyTo(it)}}
 val pm=ctx.packageManager;val info=pm.getPackageArchiveInfo(f.absolutePath,PackageManager.GET_PERMISSIONS) ?: run{f.delete();return "Could not parse APK. Confirm it is a valid Android package."}
 info.applicationInfo?.sourceDir=f.absolutePath;info.applicationInfo?.publicSourceDir=f.absolutePath
 val name=info.applicationInfo?.loadLabel(pm)?.toString() ?: "(unavailable)"
 val perms=info.requestedPermissions?.joinToString("\n"){"• $it"} ?: "No declared permissions found."
 val result=buildString{appendLine("Application: $name");appendLine("Package: ${info.packageName}");appendLine("Version: ${info.versionName ?: "unknown"}");appendLine("APK size: ${f.length()/1024} KB");appendLine("Minimum SDK: ${info.applicationInfo?.minSdkVersion ?: "unavailable"}");appendLine("Target SDK: ${info.applicationInfo?.targetSdkVersion ?: "unavailable"}");appendLine("\nDeclared permissions:\n$perms\n\nSigning-certificate fingerprints are not included in this starter build.")}
 f.delete();result
}catch(e:Exception){"Could not inspect APK: ${e.message ?: "unsupported file"}"}

@Composable private fun HistoryPage(db:AppDatabase,refresh:Int){
 var rows by remember{mutableStateOf(listOf<EditHistory>())};val scope= rememberCoroutineScope()
 LaunchedEffect(refresh){rows=db.historyDao().all()}
 Column(Modifier.fillMaxSize().padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("Editing History",fontSize=23.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));TextButton(onClick={scope.launch{db.historyDao().clear();rows=emptyList()}}){Text("Clear")}};Text("Stored locally on this device.",color=MUTED,fontSize=12.sp)
 if(rows.isEmpty())Text("No editing sessions recorded yet.",color=MUTED) else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(rows){r->CardBlock{Text(r.target,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis);Text("${r.elementType} • ${DateFormat.getDateTimeInstance().format(Date(r.timestamp))}",color=MUTED,fontSize=10.sp);Text("Before: ${r.originalText}",color=MUTED,fontSize=12.sp);Text("After: ${r.replacementText}",fontSize=12.sp);Text(r.result,color=Color(0xFF62D6A5),fontSize=11.sp)}}}
 }
}
