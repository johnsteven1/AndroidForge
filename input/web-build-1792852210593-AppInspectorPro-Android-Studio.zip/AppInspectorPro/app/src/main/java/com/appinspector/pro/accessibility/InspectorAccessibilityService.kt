package com.appinspector.pro.accessibility
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
/**
 * Opt-in service. This starter deliberately does not persist or transmit cross-app content.
 * Android accessibility events do not grant universal rights to rewrite another app's view state.
 */
class InspectorAccessibilityService : AccessibilityService() {
 override fun onAccessibilityEvent(event: AccessibilityEvent?) {
  if (event == null) return
  // Consume only the event lifecycle. Add explicit, user-initiated node inspection UI here.
 }
 override fun onInterrupt() {}
}
