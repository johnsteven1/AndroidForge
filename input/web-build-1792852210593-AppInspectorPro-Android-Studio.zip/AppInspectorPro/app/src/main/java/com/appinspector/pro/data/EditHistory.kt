package com.appinspector.pro.data
import android.content.Context
import androidx.room.*
@Entity(tableName = "edit_history")
data class EditHistory(@PrimaryKey(autoGenerate = true) val id: Long = 0, val target: String,
 val elementType: String, val originalText: String, val replacementText: String, val result: String, val timestamp: Long)
@Dao interface EditHistoryDao {
 @Insert suspend fun insert(item: EditHistory)
 @Query("SELECT * FROM edit_history ORDER BY timestamp DESC") suspend fun all(): List<EditHistory>
 @Query("DELETE FROM edit_history") suspend fun clear()
}
@Database(entities = [EditHistory::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
 abstract fun historyDao(): EditHistoryDao
 companion object {
  @Volatile private var instance: AppDatabase? = null
  fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
   instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "app-inspector.db").build().also { instance = it }
  }
 }
}
