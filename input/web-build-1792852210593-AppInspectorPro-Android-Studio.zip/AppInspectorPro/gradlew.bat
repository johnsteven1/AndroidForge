@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (gradle %* & exit /b %ERRORLEVEL%)
echo Gradle is not installed. Open in Android Studio or install Gradle 8.9 and generate the official wrapper.
exit /b 1
