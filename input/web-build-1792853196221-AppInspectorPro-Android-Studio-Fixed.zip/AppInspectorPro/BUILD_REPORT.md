# App Inspector Pro — Build configuration update

This updated archive fixes a known Gradle configuration issue for Kotlin 2.0.x + Jetpack Compose: it applies the matching `org.jetbrains.kotlin.plugin.compose` Gradle plugin instead of relying on the older `composeOptions.kotlinCompilerExtensionVersion` setup. The Compose plugin version is aligned with Kotlin 2.0.21.

## Important status

- This is a source-project update, not a compiled APK.
- An Android SDK/Gradle build was not run in this environment, so successful compilation is not guaranteed.
- If AndroidForge still fails, open the failed Gradle/build step and share the first actual error or download the `AndroidForge-logs` artifact.
- The included `gradlew` helper is not a full Gradle Wrapper distribution; use AndroidForge's installed Gradle runner or open the project in Android Studio with Gradle installed.
