# Build and diagnose App Inspector Pro

## Requirements
- Android Studio or Android build runner with Android SDK Platform 35 and Build Tools/AAPT2
- JDK 17
- Gradle 8.9 (compatible with the configured Android Gradle Plugin 8.7.3)
- Network access for first-time dependency resolution

## Important wrapper note
This supplied archive does not contain `gradle/wrapper/gradle-wrapper.jar`, so its `gradlew` is only a fallback script and is not a self-contained Gradle Wrapper. In an environment with Gradle 8.9 installed, generate the official wrapper files from the project root:

```sh
gradle wrapper --gradle-version 8.9 --distribution-type bin
```

Commit/include `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`, and `gradle/wrapper/gradle-wrapper.properties` together. Do not upload only the properties file as a complete wrapper.

## Validate resources and build

```sh
python3 tools/validate_android_resources.py
./gradlew clean
./gradlew :app:mergeDebugResources --stacktrace --info
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

Confirm `app/build/outputs/apk/debug/app-debug.apk` exists after the debug task succeeds. The static validation script does not replace AAPT2/Gradle validation and cannot inspect dependency resources that have not been downloaded/generated.

## AndroidForge investigation

Upload the project ZIP, use JDK 17 and the project's Gradle 8.9 wrapper, and run the resource task with stacktrace/info logging. If the same Unicode error occurs, download the complete AndroidForge build logs and identify the exact resource file/path and artifact/version mentioned before changing resource names or dependencies. The source XML in this archive does not contain `{str}` or malformed `\\u` escapes, so the actual failing generated/dependency resource must be identified from the full log.

Overlay and Accessibility permissions remain optional and must be granted by the user. APK access uses Android's system document picker.
