#!/usr/bin/env python3
"""Static checks for Android resource XML and suspicious Unicode escapes.

This does not replace aapt2/Gradle. Run from the project root:
    python3 tools/validate_android_resources.py
"""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RESOURCE_ROOTS = [ROOT / "app" / "src", ROOT / "app" / "build" / "generated"]
XML_FILES = []
for base in RESOURCE_ROOTS:
    if base.exists():
        XML_FILES.extend(base.rglob("*.xml"))

errors = []
for path in sorted(set(XML_FILES)):
    try:
        ET.parse(path)
    except ET.ParseError as exc:
        errors.append(f"Malformed XML: {path.relative_to(ROOT)}: {exc}")

# Search text-based project inputs for the reported placeholder and malformed
# Java/Android-style Unicode escape forms. Escaped source literals are reported
# as evidence only; AAPT2 remains the authority for Android resource semantics.
TEXT_SUFFIXES = {".xml", ".kt", ".kts", ".properties", ".gradle", ".java", ".txt"}
files = []
for base in (ROOT / "app" / "src", ROOT / "gradle", ROOT):
    if base.exists():
        files.extend(p for p in base.rglob("*") if p.is_file() and p.suffix in TEXT_SUFFIXES and ".gradle/" not in str(p))
seen = set()
for path in sorted(files):
    if path in seen:
        continue
    seen.add(path)
    try:
        text = path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        continue
    if "{str}" in text:
        errors.append(f"Literal '{{str}}' found: {path.relative_to(ROOT)}")
    for number, line in enumerate(text.splitlines(), 1):
        # Match a literal backslash-u not followed by four hexadecimal digits.
        for match in re.finditer(r"\\u(?![0-9a-fA-F]{4})", line):
            errors.append(f"Suspicious Unicode escape at {path.relative_to(ROOT)}:{number}: {line.strip()}")

if errors:
    print("STATIC VALIDATION: FAIL")
    print("\n".join(f"- {item}" for item in errors))
    sys.exit(1)

print(f"STATIC VALIDATION: PASS — parsed {len(set(XML_FILES))} XML file(s); no literal '{{str}}' or malformed \\u escape found in scanned project inputs.")
print("Note: dependency/generated resources and AAPT2 compilation are checked only by a real Gradle Android build.")
