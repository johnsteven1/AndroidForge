# App Inspector Pro

This project replaces the SecureVault project with a native Kotlin/Jetpack Compose Android Studio project.

## Included
- Dark Compose dashboard and navigation
- Edit Mode with tap-to-select text in the app's integrated WebView
- Replacement text field, apply, and undo workflow for the current page
- Launchable installed-app library
- Official Google Play Store intents with web fallback
- Read-only APK metadata inspection via Android's document picker
- Room-backed local editing history
- Movable floating shortcut overlay
- Opt-in Accessibility Service declaration
- Privacy and compatibility notes

## Build
Install Android Studio, Android SDK Platform 35 / Build Tools 35.0.0, and JDK 17. Run `python3 tools/validate_android_resources.py`, then use the commands in `BUILD_INSTRUCTIONS.md`. The expected debug APK path is `app/build/outputs/apk/debug/app-debug.apk`.

The supplied archive did not contain the official Gradle wrapper JAR. The GitHub Actions workflow bootstraps the official Gradle 8.9 wrapper in CI before running the actual Android resource and APK build tasks. A real Android build was not possible in the packaging environment because Gradle, Android SDK/AAPT2, and network access were unavailable. No APK is claimed or included.

## Use Edit Mode
Open **Edit Mode**, enter a web address, press **GO**, enable **Tap-to-select**, tap a text-bearing element, edit the replacement field, then press **APPLY**. Changes affect the current WebView DOM only. Reloading may discard them.

## Google Play
The Play Store screen opens official `market://` intents and falls back to the official Google Play website if the app is unavailable. It does not copy Google's UI or bypass installation consent.

## Cross-app inspection
The app library lists launchable apps visible under Android package-visibility rules. The **INSPECT** action opens Android Accessibility settings. The service must be enabled manually and does not rewrite another app's private view state. Android does not permit universal arbitrary text modification across unrelated apps.

## APK Inspector
Choose an APK with the system document picker. It is parsed locally and is not executed or installed. This starter shows app/package/version, size, SDK values where available, and declared permissions. Certificate fingerprints, resource browsing, APK rebuilding, and signing are not implemented.

## Floating inspector
Settings > Floating inspector requests overlay permission when enabled. Tap the movable pencil to return to App Inspector Pro; long-press to stop it.

## Privacy
No inspected content is uploaded by this project. Imported APKs are read locally. History is stored locally and can be cleared. Review current Google Play policies before publishing, especially policies governing Accessibility Services and overlays.
