# Build and diagnose App Inspector Pro

## Local Android Studio build

1. Install Android Studio, Android SDK Platform 35, Build Tools 35.0.0, and JDK 17.
2. Open the `AppInspectorPro` project folder.
3. Run `python3 tools/validate_android_resources.py`.
4. If the project does not yet have `gradle/wrapper/gradle-wrapper.jar`, run this once from the project root in an environment with Gradle 8.9 installed:

   ```sh
   gradle wrapper --gradle-version 8.9 --distribution-type bin
   ```

5. Run the following commands and keep the complete output:

   ```sh
   ./gradlew --version
   ./gradlew clean
   ./gradlew :app:processDebugResources --stacktrace --info
   ./gradlew :app:assembleDebug --stacktrace --info
   ./gradlew :app:assembleRelease --stacktrace --info
   ./gradlew :app:bundleDebug --stacktrace --info
   ```

6. Confirm the debug APK exists at `app/build/outputs/apk/debug/app-debug.apk`. The static validator is not a substitute for AAPT2 or Gradle compilation.

## GitHub Actions

Push the project to GitHub and open **Actions → Android build**. The workflow installs JDK 17 and Android SDK 35, installs Gradle 8.9 for wrapper bootstrapping, creates the official wrapper if missing, and runs the resource/debug/release/bundle tasks. Successful builds upload the generated APK/AAB. Failed builds upload resource intermediates and complete command logs.

The wrapper JAR is not present in this source archive because it was not included in the supplied project and this packaging environment cannot access external downloads. The workflow creates the standard Gradle wrapper in the CI workspace before building. To commit it permanently, run the wrapper-generation command above locally and commit `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`, and `gradle/wrapper/gradle-wrapper.properties`.

## AndroidForge

Upload the full project ZIP and select JDK 17 and Gradle 8.9. If AndroidForge uses its own Gradle invocation, run the same commands from the project root. Download the complete failure diagnostics if resource compilation fails. Inspect the exact merged file reported by AAPT2, not only the source `strings.xml`.

## Existing functionality

The resource correction retains the opt-in Accessibility Service declaration. Existing Compose/WebView, text selection and replacement, floating inspector, installed-app library, Play Store links, APK metadata inspection, file picker, edit history, settings, and documentation source files are retained. Cross-app editing remains limited by Android's permission and accessibility APIs.
