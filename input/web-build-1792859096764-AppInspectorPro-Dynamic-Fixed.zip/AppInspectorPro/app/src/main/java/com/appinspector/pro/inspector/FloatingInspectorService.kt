package com.appinspector.pro.inspector
import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.TextView
import com.appinspector.pro.MainActivity

class FloatingInspectorService : Service() {
 private var wm: WindowManager? = null
 private var bubble: View? = null
 override fun onCreate() {
  super.onCreate()
  if (Build.VERSION.SDK_INT >= 26) {
   getSystemService(NotificationManager::class.java).createNotificationChannel(
    NotificationChannel("inspector", "Floating Inspector", NotificationManager.IMPORTANCE_LOW))
  }
  val notification = if (Build.VERSION.SDK_INT >= 26)
   Notification.Builder(this, "inspector").setContentTitle("App Inspector Pro").setContentText("Floating control active").setSmallIcon(android.R.drawable.ic_menu_edit).build()
  else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("App Inspector Pro").setContentText("Floating control active").setSmallIcon(android.R.drawable.ic_menu_edit).build()
  startForeground(1001, notification)
  if (Settings.canDrawOverlays(this)) addBubble() else stopSelf()
 }
 private fun addBubble() {
  wm = getSystemService(WINDOW_SERVICE) as WindowManager
  val v = TextView(this).apply { text = "✎"; textSize = 24f; setTextColor(-1); setBackgroundColor(0xFF6F5BFF.toInt()); gravity = Gravity.CENTER; setPadding(18, 10, 18, 10) }
  val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
  val p = WindowManager.LayoutParams(-2, -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
  val density=resources.displayMetrics.density
  p.gravity = Gravity.TOP or Gravity.START
  p.x = (24f*density).toInt()
  p.y = (120f*density).toInt()
  var x0 = 0; var y0 = 0; var tx = 0f; var ty = 0f; var dragged = false
  v.setOnTouchListener { _, e ->
   when (e.action) {
    MotionEvent.ACTION_DOWN -> { x0=p.x; y0=p.y; tx=e.rawX; ty=e.rawY; dragged=false; true }
    MotionEvent.ACTION_MOVE -> {
     val dx=(e.rawX-tx).toInt(); val dy=(e.rawY-ty).toInt()
     if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>(8f*density).toInt()) dragged=true
     val metrics=resources.displayMetrics
     p.x=(x0+dx).coerceIn(0,(metrics.widthPixels-v.width).coerceAtLeast(0))
     p.y=(y0+dy).coerceIn(0,(metrics.heightPixels-v.height).coerceAtLeast(0))
     try { wm?.updateViewLayout(v,p) } catch(_:Exception) { stopSelf() }
     true
    }
    MotionEvent.ACTION_UP -> { if (!dragged) startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)); true }
    else -> false
   }
  }
  v.setOnLongClickListener { stopSelf(); true }
  bubble=v
  try { wm?.addView(v,p) } catch (_: Exception) { stopSelf() }
 }
 override fun onDestroy() { try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}; bubble=null; stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy() }
 override fun onBind(intent: Intent?): IBinder? = null
}
