#!/usr/bin/env python3
"""Validate source Android XML/resources before invoking AAPT2.

Run from the project root:
    python3 tools/validate_android_resources.py

This is a static preflight only; a real Gradle/AAPT2 build is still required.
"""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "app" / "src"
xml_files = sorted(SRC.rglob("*.xml")) if SRC.exists() else []
errors = []

for path in xml_files:
    try:
        tree = ET.parse(path)
    except ET.ParseError as exc:
        errors.append(f"Malformed XML: {path.relative_to(ROOT)}: {exc}")
        continue

    # AAPT2 string values treat apostrophes and backslashes specially. Check
    # string resources specifically, not arbitrary code or documentation.
    if path.parent.name == "values":
        seen = set()
        for node in tree.getroot().iter():
            if node.tag not in {"string", "plurals", "string-array", "item"}:
                continue
            name = node.attrib.get("name")
            if name:
                if name in seen:
                    errors.append(f"Duplicate resource name {name!r}: {path.relative_to(ROOT)}")
                seen.add(name)
            if node.tag != "string" or node.text is None:
                continue
            value = node.text
            if "{str}" in value:
                errors.append(f"Literal '{{str}}' found in resource {name!r}: {path.relative_to(ROOT)}")
            # Check literal backslash-u sequences in Android string values.
            for match in re.finditer(r"\\u(?![0-9a-fA-F]{4})", value):
                errors.append(
                    f"Suspicious Unicode escape in resource {name!r}: "
                    f"{path.relative_to(ROOT)} offset {match.start()}"
                )
            # Apostrophes must be escaped or the whole string must be quoted.
            if not (len(value) >= 2 and value[0] == value[-1] == '"'):
                for match in re.finditer("'", value):
                    backslashes = 0
                    i = match.start() - 1
                    while i >= 0 and value[i] == "\\":
                        backslashes += 1
                        i -= 1
                    if backslashes % 2 == 0:
                        errors.append(
                            f"Unescaped apostrophe in resource {name!r}: "
                            f"{path.relative_to(ROOT)} offset {match.start()}"
                        )

if errors:
    print("STATIC RESOURCE VALIDATION: FAIL")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)

print(f"STATIC RESOURCE VALIDATION: PASS — parsed {len(xml_files)} source XML file(s).")
print("No suspicious {str} placeholder, malformed Unicode escape, duplicate value-resource name, or unescaped string apostrophe found.")
print("This preflight does not replace a real Gradle/AAPT2 build or inspect unresolved dependency resources.")
