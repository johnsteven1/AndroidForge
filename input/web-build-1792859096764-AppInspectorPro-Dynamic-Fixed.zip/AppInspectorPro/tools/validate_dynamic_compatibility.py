#!/usr/bin/env python3
"""Static regression checks for AppInspectorPro's adaptive-safety changes.

This is not a Kotlin compiler and does not replace a Gradle/AAPT2 build.
"""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/appinspector/pro/MainActivity.kt"
FLOATING = ROOT / "app/src/main/java/com/appinspector/pro/inspector/FloatingInspectorService.kt"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
errors = []

def require(condition, message):
    if not condition:
        errors.append(message)

main = MAIN.read_text(encoding="utf-8")
floating = FLOATING.read_text(encoding="utf-8")
manifest = MANIFEST.read_text(encoding="utf-8")

# Regression checks for the exact StorePage syntax failure in AndroidForge logs.
require("OutlinedButton(onClick={try{" not in main,
        "The malformed one-line StorePage OutlinedButton expression is still present.")
require("private fun normalizeWebUrl" in main, "Missing dynamic URL validation.")
require('scheme!="http" && scheme!="https"' in main, "URL validation must restrict navigation to HTTP/HTTPS.")
require("settings.allowFileAccess=false" in main and "settings.allowContentAccess=false" in main,
        "WebView local file/content access must be disabled.")
require("WebSettings.MIXED_CONTENT_NEVER_ALLOW" in main and "settings.safeBrowsingEnabled=true" in main,
        "WebView security settings are incomplete.")
require("onReceivedError" in main and "onReceivedHttpError" in main,
        "WebView load failures must surface as status.")
require("window.__appInspectorEnabled=false" in main,
        "Edit Mode must disable the DOM selection listener when switched off.")
require("openExternalWithFallback" in main, "Store links need a fallback launch path.")
require("private fun describeSelectedFile" in main and "filePicker.launch(arrayOf(\"*/*\"))" in main,
        "File Manager must use its own picker/details workflow.")
require("maxBytes=256L*1024L*1024L" in main and "finally" in main and "file.delete()" in main,
        "APK inspection needs a bounded copy and temporary-file cleanup.")
require("withContext(Dispatchers.IO)" in main, "File inspection must not block the main UI thread.")
require("(24f*density).toInt()" in floating and "coerceIn(0," in floating,
        "Floating inspector coordinates must scale with density and stay within display bounds.")
require("android.permission.INTERNET" in manifest, "INTERNET permission is missing.")

try:
    ET.parse(MANIFEST)
except ET.ParseError as exc:
    errors.append(f"Manifest XML is malformed: {exc}")

# Delimiter scan for Kotlin source, ignoring comments and quoted strings.
def check_delimiters(source, label):
    stack = []
    pairs = {")": "(", "]": "[", "}": "{"}
    i = 0
    state = "code"
    while i < len(source):
        ch = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ""
        if state == "line_comment":
            if ch == "\n": state = "code"
        elif state == "block_comment":
            if ch == "*" and nxt == "/":
                state = "code"; i += 1
        elif state == "string":
            if ch == "\\": i += 1
            elif ch == '"': state = "code"
        elif state == "triple":
            if source.startswith('"""', i):
                state = "code"; i += 2
        elif state == "char":
            if ch == "\\": i += 1
            elif ch == "'": state = "code"
        else:
            if ch == "/" and nxt == "/":
                state = "line_comment"; i += 1
            elif ch == "/" and nxt == "*":
                state = "block_comment"; i += 1
            elif source.startswith('"""', i):
                state = "triple"; i += 2
            elif ch == '"':
                state = "string"
            elif ch == "'":
                state = "char"
            elif ch in "([{":
                stack.append((ch, source.count("\n", 0, i) + 1))
            elif ch in ")]}":
                if not stack or stack[-1][0] != pairs[ch]:
                    errors.append(f"{label}: unmatched {ch!r} near line {source.count(chr(10), 0, i) + 1}")
                else:
                    stack.pop()
        i += 1
    if stack:
        errors.append(f"{label}: unclosed delimiters: {stack[-5:]}")
    if state in {"string", "triple", "char", "block_comment"}:
        errors.append(f"{label}: unterminated {state}")

check_delimiters(main, "MainActivity.kt")
check_delimiters(floating, "FloatingInspectorService.kt")

if errors:
    print("DYNAMIC COMPATIBILITY PREFLIGHT: FAIL")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)

print("DYNAMIC COMPATIBILITY PREFLIGHT: PASS")
print("Checked URL validation, WebView restrictions/errors, edit-mode toggling, safe external fallback, bounded APK inspection, background file work, overlay bounds, manifest, and Kotlin delimiter balance.")
print("This is a static regression preflight only; it does not compile Kotlin or build an APK.")
